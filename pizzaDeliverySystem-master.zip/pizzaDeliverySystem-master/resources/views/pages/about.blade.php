@extends('layout.app')
      <h1>Welcome to about page.</h1>
@section('content')
    
@endsection 
