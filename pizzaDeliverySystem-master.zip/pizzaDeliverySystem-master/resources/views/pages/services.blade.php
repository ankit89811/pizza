@extends('layout.app')
<title>{{$title}}</title>
<h1>Welcome to the Services page.</h1>
@section('content')
    
@endsection  
   
