<h1>{{$products}}</h1>
<h1>{{$amount}}</h1>
<h1>{{$ad}}</h1>